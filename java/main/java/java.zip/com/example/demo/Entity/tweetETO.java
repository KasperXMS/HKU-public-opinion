package com.example.demo.Entity;

import lombok.Data;

@Data
public class tweetETO {
    private String text;
    private  int favoriteCount;
    private String score;
}
