package com.example.demo.Entity;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class weiboDto {

    private String text;
    private int likes;
    private String score;
}
