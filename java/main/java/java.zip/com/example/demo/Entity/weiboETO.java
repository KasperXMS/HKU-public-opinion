package com.example.demo.Entity;

import lombok.Data;

@Data
public class weiboETO {
    private String text;
    private int likes;
    private String score;
}
